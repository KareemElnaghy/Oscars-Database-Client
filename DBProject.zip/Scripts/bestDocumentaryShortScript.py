import requests
from bs4 import BeautifulSoup
import csv
import re

# Fetch the Wikipedia page
url = "https://en.wikipedia.org/wiki/Academy_Award_for_Best_Documentary_Short_Film"
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# Prepare data storage
data = []  # Main data list
PeopleLinks = set()  # Global set to store unique nominee links

# Find all wikitable tables on the page
tables = soup.find_all('table', class_='wikitable')

current_year = None  # Track current year
current_iteration = None  # Track current iteration

# Iterate through tables
for table in tables:
    rows = table.find_all('tr')[1:]  # Skip header row

    for i, row in enumerate(rows):
        cols = row.find_all(['td', 'th'])

        # Handle rows with <th> (release year and iteration)
        if cols and cols[0].name == 'th':  # Year and iteration are in <th>
            year_text = cols[0].get_text(strip=True)
            match_year = re.search(r'(\d{4})', year_text)
            match_iteration = re.search(r'\((\d+(?:st|nd|rd|th))\)', year_text)

            if match_year:
                current_year = int(match_year.group(1))
            if match_iteration:
                current_iteration = match_iteration.group(1)

            # Process the rest of this row if it contains film info
            if len(cols) > 2:  # If there's film info in this row
                film_cell = cols[1]
                nominee_cell = cols[2]
            else:
                continue  # Skip to next row if this row only has year info
        else:
            # For rows without <th>, film is in cols[0] and nominees in cols[1]
            if len(cols) < 2:
                continue  # Skip rows without enough columns

            film_cell = cols[0]
            nominee_cell = cols[1]

        # Extract film title
        film_title_tag = film_cell.find('i')  # Find the <i> tag inside <td>
        if not film_title_tag:
            continue

        film_title_link_tag = film_title_tag.find('a')  # Check for nested <a> tag
        movie_title = (
            film_title_link_tag.get_text(strip=True)
            if film_title_link_tag
            else film_title_tag.get_text(strip=True)
        )

        # Check winner status (winners are marked with bold text, background color, or ‡)
        is_winner = bool(film_cell.find('b')) or "background:#FAEB86" in str(row)
        winner_status = "yes" if is_winner else "no"

        # Extract nominees from the nominee cell
        nominees_info = []
        nominee_links = nominee_cell.find_all('a')

        for link in nominee_links:
            nominee_name = link.get_text(strip=True)
            nominee_url = f"https://en.wikipedia.org{link['href']}"

            # Split the name and count the number of words
            name_parts = nominee_name.split()

            # Check if it's likely a person (3 or fewer words in name)
            if len(name_parts) <= 3:
                nominees_info.append({
                    'nomineeName': nominee_name,
                    'nomineeLink': nominee_url
                })
                PeopleLinks.add(nominee_url)
            else:
                print("Invalid: ",nominee_name)

        entry_data = {
            'movieTitle': movie_title,
            'releaseYear': current_year,
            'categoryName': "Best Documentary Short Film",
            'iteration': current_iteration,
            'isWinner': winner_status,
            'nominees': nominees_info
        }

        data.append(entry_data)
        print(f"Added entry: {movie_title} ({current_year}) - Winner: {winner_status}")

# Save detailed CSV: firstName, lastName, movieTitle, releaseYear, categoryName, iteration, isWinner
with open('best_documentary_short_full_details.csv', mode='w', encoding='utf-8', newline='') as file1:
    writer1 = csv.writer(file1)
    writer1.writerow(['firstName', 'lastName', 'movieTitle', 'releaseYear',
                      'categoryName', 'iteration', 'isWinner'])
    for entry in data:
        for nominee in entry['nominees']:
            full_name_parts = nominee['nomineeName'].split(" ", 1)
            first_name = full_name_parts[0]
            last_name = full_name_parts[1] if len(full_name_parts) > 1 else ""

            writer1.writerow([
                first_name,
                last_name,
                entry['movieTitle'],
                entry['releaseYear'],
                entry['categoryName'],
                entry['iteration'],
                entry['isWinner']
            ])

# Save basic CSV: firstName, lastName, movieTitle, releaseYear
with open('best_documentary_short_basic.csv', mode='w', encoding='utf-8', newline='') as file2:
    writer2 = csv.writer(file2)
    writer2.writerow(['firstName', 'lastName', 'movieTitle', 'releaseYear'])
    for entry in data:
        for nominee in entry['nominees']:
            full_name_parts = nominee['nomineeName'].split(" ", 1)
            first_name = full_name_parts[0]
            last_name = full_name_parts[1] if len(full_name_parts) > 1 else ""

            writer2.writerow([
                first_name,
                last_name,
                entry['movieTitle'],
                entry['releaseYear']
            ])

print("Scraped data saved to CSV files.")
print(f"Total entries: {len(data)}")
print(f"Total unique people links collected: {len(PeopleLinks)}")
