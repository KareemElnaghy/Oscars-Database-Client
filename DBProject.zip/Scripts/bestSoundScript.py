import requests
from bs4 import BeautifulSoup
import csv
import re

# Fetch the Wikipedia page for Best Production Design
url = "https://en.wikipedia.org/wiki/Academy_Award_for_Best_Production_Design"
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# Prepare data storage
data = []
PeopleLinks = set()

# Find all wikitable tables on the page
tables = soup.find_all('table', class_='wikitable')

current_year = None  # Track current year
current_iteration = None  # Track current iteration

# Iterate through tables
for table in tables:
    rows = table.find_all('tr')[1:]  # Skip header row

    for row in rows:
        cols = row.find_all(['td', 'th'])

        # Handle rows with a <td> containing year and iteration (spanning multiple rows)
        if cols and len(cols) == 1 and cols[0].name == 'td' and "rowspan" in cols[0].attrs:
            year_text = cols[0].get_text(strip=True)
            match_year = re.search(r'(\d{4})', year_text)
            match_iteration = re.search(r'\((\d+(?:st|nd|rd|th))\)', year_text)

            if match_year:
                current_year = int(match_year.group(1))
            if match_iteration:
                current_iteration = match_iteration.group(1)

            continue  # Skip to next row since this row only contains year info

        # Skip rows without enough columns to process
        if len(cols) < 3:
            continue

        # Extract film title from the first column
        film_cell = cols[0]
        film_title_tag = film_cell.find('i')  # Find the <i> tag inside <td>
        if not film_title_tag:
            continue

        film_title_link_tag = film_title_tag.find('a')  # Check for nested <a> tag
        movie_title = (
            film_title_link_tag.get_text(strip=True)
            if film_title_link_tag
            else film_title_tag.get_text(strip=True)
        )

        # Check winner status (background color or bold text indicates winner)
        is_winner = "yes" if ("background:#FAEB86" in row.get("style", "") or bool(row.find('b'))) else "no"

        # Extract nominees from the second column
        nominees_info = []
        nominee_cell_1 = cols[1]
        nominee_links_tags_1 = nominee_cell_1.find_all('a')

        for link in nominee_links_tags_1:
            nominee_name = link.get_text(strip=True)
            nominee_url = f"https://en.wikipedia.org{link['href']}"
            PeopleLinks.add(nominee_url)

            nominees_info.append({'nomineeName': nominee_name, 'nomineeLink': nominee_url})

        # If there is a third column, extract additional nominees (for cases where nominees are split across two columns)
        if len(cols) > 2:
            nominee_cell_2 = cols[2]
            nominee_links_tags_2 = nominee_cell_2.find_all('a')

            for link in nominee_links_tags_2:
                nominee_name = link.get_text(strip=True)
                nominee_url = f"https://en.wikipedia.org{link['href']}"
                PeopleLinks.add(nominee_url)

                nominees_info.append({'nomineeName': nominee_name, 'nomineeLink': nominee_url})

        entry_data = {
            'movieTitle': movie_title,
            'releaseYear': current_year,
            'categoryName': "Best Production Design",
            'iteration': current_iteration,
            'isWinner': is_winner,
            'nominees': nominees_info
        }

        data.append(entry_data)

# Save detailed CSV: firstName, lastName, movieTitle, releaseYear, categoryName, iteration, isWinner
with open('best_production_design_full_details.csv', mode='w', encoding='utf-8', newline='') as file1:
    writer1 = csv.writer(file1)
    writer1.writerow(['firstName', 'lastName', 'movieTitle', 'releaseYear',
                      'categoryName', 'iteration', 'isWinner'])
    for entry in data:
        for nominee in entry['nominees']:
            full_name_parts = nominee['nomineeName'].split(" ", 1)
            first_name = full_name_parts[0]
            last_name = full_name_parts[1] if len(full_name_parts) > 1 else ""

            writer1.writerow([
                first_name,
                last_name,
                entry['movieTitle'],
                entry['releaseYear'],
                entry['categoryName'],
                entry['iteration'],
                entry['isWinner']
            ])

print(f"Total unique people links collected: {len(PeopleLinks)}")
